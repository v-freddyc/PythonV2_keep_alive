import datetime
import logging
import requests

import azure.functions as func


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    URL = "https://fn-9907-fme.azurewebsites.net/api/http_trigger?name=FME-trigger"
    r = requests.post(url=URL)
    logging.info('FMELogs - '+r.text)
    logging.info('FME: Python timer trigger function ran at %s', utc_timestamp)
